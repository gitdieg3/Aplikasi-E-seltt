<?php
include 'conn.php';

//function insert data


function insertdata($nama_barang, $katagori, $jumlah, $harga, $tanggal, $conn) {
    $stmt = $conn->prepare("INSERT INTO tabel_barang (nama_barang, katagori, jumlah, harga, tanggal) VALUES (?, ?, ?, ?, ?)");

    if ($stmt) {
        $stmt->bind_param("sssss", $nama_barang, $katagori, $jumlah, $harga, $tanggal);
        
        if ($stmt->execute()) {
            $stmt->close();
            return "Data berhasil disimpan ke database.";
        } else {
            $error = "Error saat eksekusi: " . $stmt->error;
            $stmt->close();
            return $error;
        }
    } else {
        return "Error saat prepare statement: " . $conn->error;
    }
}
// select id saat edit product
function ambil_Id($conn, $id) {
    $sql = "SELECT * FROM tabel_barang WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        return mysqli_fetch_array($result);
    } else {
        return false;
    }
}

// fungsi untuk update product
function update_barang($conn, $id, $nama_barang, $katagori, $jumlah, $harga, $tanggal) {
    $sql = "UPDATE tabel_barang 
            SET nama_barang = '$nama_barang',
                katagori = '$katagori',
                jumlah = '$jumlah',
                harga = '$harga',
                tanggal = '$tanggal'
            WHERE id = '$id'";
    
    return mysqli_query($conn, $sql);
}
// fungsi untuk delate data product
function delete_barang($conn, $id) {
    $sql = "DELETE FROM tabel_barang WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        return "Produk berhasil dihapus.";
    } else {
        return "Gagal menghapus produk: " . mysqli_error($conn);
    }
}


?>