<?php
include 'conn.php';
include 'function.php';

$nama_barang = "";
$katagori = "";
$jumlah = "";
$harga = "";
$tanggal = "";
$sukses = "";
$error = "";
$warning = "";

$op = $_GET['op'] ?? "";

if ($op == 'edit' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $produk = ambil_id($conn, $id);

    if ($produk) {
        $nama_barang = $produk['nama_barang'];
        $katagori = $produk['katagori'];
        $jumlah = $produk['jumlah'];
        $harga = $produk['harga'];
        $tanggal = $produk['tanggal'];
    } else {
        $error = "Data tidak ditemukan!";
    }
}

if (isset($_POST['update'])) {
    $id          = ($_GET['id']);
    $nama_barang = ($_POST['nama_barang']);
    $katagori    = ($_POST['katagori']);
    $jumlah      = ($_POST['jumlah']);
    $harga       = ($_POST['harga']);
    $tanggal     = ($_POST['tanggal']);

    if ($nama_barang && $katagori && $jumlah && $harga && $tanggal) {
        if (update_barang($conn, $id, $nama_barang, $katagori, $jumlah, $harga, $tanggal)) {
            $sukses = "Data berhasil diupdate!";
        } else {
            $error = "Terjadi kesalahan saat memperbarui data: " . mysqli_error($conn);
        }
    } else {
        $warning = "Pastikan semua input terisi dengan benar.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php include 'layouts/notifikasi.php'; ?>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">E-Selt</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigasi">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="tambah.php">Tambah Data</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded p-4">
            <div class="container mt-3">
                <h3>EDIT DATA BARANG</h3>
                <form action="" method="POST">
                    <input type="hidden" name="id" value="<?php echo $_GET['id'] ?? ''; ?>">

                    <div class="mb-3">
                        <label for="nama_barang" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" id="nama_barang" name="nama_barang"
                            value="<?php echo $nama_barang; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="katagori" class="form-label">Kategori Barang</label>
                        <select class="form-select" id="katagori" name="katagori" required>
                            <option value="">-- Pilih katagori --</option>
                            <option value="perangkat keras" <?php if ($katagori == 'perangkat keras') echo 'selected'; ?>>perangkat keras</option>
                            <option value="perangkat lunak" <?php if ($katagori == 'perangkat lunak') echo 'selected'; ?>>perangkat lunak</option>
                            <option value="set up" <?php if ($katagori == 'set up') echo 'selected'; ?>>set up</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Jumlah Stock</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah"
                            value="<?php echo $jumlah; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="harga" class="form-label">Harga Barang</label>
                        <input type="number" class="form-control" id="harga" name="harga"
                            value="<?php echo $harga; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal"
                            value="<?php echo $tanggal; ?>" required>
                    </div>

                    <button type="submit" name="update" class="btn btn-primary">Ubah</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>